A module for comics lovers, which prints the qutoes from super heros of marvel & dc comics and movies.
