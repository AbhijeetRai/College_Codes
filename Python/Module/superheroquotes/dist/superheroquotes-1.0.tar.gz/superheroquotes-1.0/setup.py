from setuptools import setup

setup (

	name = 'superheroquotes',
	version = '1.0',
	author = 'Abhijeet Rai',
	author_email = 'abraj306@gmail.com',
	url = 'https://github.com/AbhijeetRai/superheroquotes',
	keywords = ['Super hero quotes', 'Superhero quotes', 'Marvel', 'DC', 'dc', 'Dc'],
	description = 'A module to print quotes from marvel, dc comics and movies',
	py_modules = ['superheroquotes'],
)
